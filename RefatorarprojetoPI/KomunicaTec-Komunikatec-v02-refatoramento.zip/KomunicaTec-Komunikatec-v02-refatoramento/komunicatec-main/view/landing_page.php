<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Estilos CSS -->
	<!--link rel="stylesheet" href="style.css"-->
	<!--link rel="stylesheet" href="reset.css"-->
	<!-- Fontes Google -->
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<title>KomunikaTec</title>
</head>

<body>

	<!-- Cabeçalho e navegação principal -->
	<?php
	include_once 'cabecario.php';
	?>

	<!-- Conteúdo principal com destaque -->
	<main>
		<section class="imagem-fundo">
			<div class="overlay">
				<article class="main">
					<h1 class="texto-principal">|Bem vindo(a) a KomunicaTec!</h1>
					<p class="texto-imagem">A plataforma de comunicação da Fatec Franco da Rocha.</p>
					<button class="botao-visualizar" onclick="location.href='publicacao_usuario.php'">visualizar novidades</button>
				</article>
			</div>
		</section>
	</main>

	<!-- Seção sobre a plataforma -->
	<h2 class="titulo-login exibir-central">|Sobre a plataforma</h2>

	<section class="fundo-login">
		<div class="caixa-acesso">
			<article>
				<figure>
					<img class="divisao-imagem" src="imagens/imgin.png" alt="Ilustração sobre comunicação acadêmica">
				</figure>
				<aside class="login-size">
					<p class="span-login exibir-central">
						A KomunicaTec é uma plataforma para apoio à comunicação e integração da comunidade acadêmica da Fatec
						Franco da Rocha.<br>
						Fique por dentro de vagas publicadas, cursos e até mesmo convites para eventos.<br><br><br>
						Mantenha contato com a instituição mesmo após a formação, tendo acesso contínuo às possibilidades fornecidas por ela.
					</p>
				</aside>
			</article>
		</div>
	</section>
	<!-- Rodapé -->
	<footer class="text-center py-3">
		<img class="rodape-acesso" src="imagens/logo2.png" alt="Logo secundária da KomunikaTec">
	</footer>
</body>

</html>